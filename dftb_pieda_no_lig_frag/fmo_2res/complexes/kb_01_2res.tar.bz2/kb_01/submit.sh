#!/bin/bash
 xgms=/work/LAS/mgordon-lab/tsatta/gamess-dev-cpu/gms
# xgms=/work/LAS/mgordon-lab/meganthegreat/gamess-current/gmsmegmpi
 for i in *inp;do
 log=${i%.inp}.log
# $xgms -p 32  -w 00:15:00 $i -l $log
 $xgms -p 32 -logn 1 -w 00:15:00 $i -l $log
 done
