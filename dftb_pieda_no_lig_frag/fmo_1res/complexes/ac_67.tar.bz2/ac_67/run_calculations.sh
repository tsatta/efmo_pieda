#!/bin/bash

# Check that a path was provided
if [ -z "$1" ]; then
    echo "Missing argument."
    exit 1
fi

# Path to the base directory given by the user
base_dir="$1"

# Path to sub script 
sub_script="/mnt/lustre/koa/lab/tsqc_group/loreab/scripts/subgms_mpi_ddi.sh"

# Find all .inp files
find "$base_dir" -type f -name "*.inp" | while read -r inp_file; do
    echo "Submitting calculation for: $inp_file"
    sbatch "$sub_script" "$inp_file"
done

rm ./slurm*.out

echo "All calculations submitted."
